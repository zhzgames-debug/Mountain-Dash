# Mountain Dash v4 — Android Rebuild

Android-first endless runner set in a Gilgit/Danyor-inspired mountain valley.

## Current visual/gameplay pass
- 3-lane endless-run presentation with perspective road
- Snow-capped Karakoram-style peaks, turquoise river, fields and trees
- Animated lane movement with swipe/tap controls
- Jump and slide actions
- Cars, road barriers and rocks as hazards
- Coin trails and collectible power-ups
- Shield and coin-magnet power-ups
- Animated player, vehicles, particles and road motion
- Score, coins, lives, best score and simple outfit unlock
- LocalStorage persistence for score/coins
- Frame-time cap and object/particle caps for smoother low/mid-range Android devices
- Offline HTML game bundled inside the Android APK; no network permission required

## Build
The included GitHub Actions workflow builds a debug APK with JDK 17 and Android Gradle Plugin 8.6.1.

APK output: `app/build/outputs/apk/debug/app-debug.apk`


## Latest polish pass
- Enhanced runner animation with swinging arms, alternating legs, backpack, cap and running bob.
- Added valley bridge/roadside depth details.
- Added near-miss scoring and combo streak feedback.
- Added stronger pause feedback and HUD combo indicator.
- Preserved offline operation and Android-friendly object/particle limits.

## Big Visual Upgrade
- Cinematic branded start screen with ZH Games / Karakoram Run identity.
- Stronger atmospheric valley depth, village silhouettes, utility poles and foreground terrain.
- Turquoise river crossing with bridge rails and roadside depth cues.
- New road hazards: traffic cones and danger signs.
- Higher-speed visual streak effects and richer roadside presentation.
- Existing offline Android/WebView architecture retained for stability.
